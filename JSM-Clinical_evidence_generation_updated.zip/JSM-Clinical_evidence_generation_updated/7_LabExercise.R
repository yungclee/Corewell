#############################################
### R code for phenotyping algorithm
#############################################
## Install PheCAP 
rm(list=ls())
### install.packages("devtools")
### devtools::install_github("celehs/PheCAP")
### or install source code from 
### https://github.com/celehs/PheCAP/blob/master/PheCAP_1.0.tar.gz
library(PheCAP)

## Real EHR data 
data(ehr_data)
data <- PhecapData(ehr_data, "healthcare_utilization",
                   "label", 0.4, patient_id = "patient_id")
data

### Candidate surrogates: main_ICD and main_NLP
data$frame[1:3,c(1:5,15)]

## Specify what surrogate(s) will be used
surrogates <- list(
  PhecapSurrogate(
    variable_names = "main_ICD",
    lower_cutoff = 1, upper_cutoff = 10),
  PhecapSurrogate(
    variable_names = "main_NLP",
    lower_cutoff = 1, upper_cutoff = 10),
  PhecapSurrogate(
    variable_names = c("main_ICD", "main_NLP"),
    lower_cutoff = 1, upper_cutoff = 10))

## Run surrogate-assisted feature extraction
system.time(feature_selected <- 
              phecap_run_feature_extraction(data, surrogates))
feature_selected

## Train phenotyping model 
model <- phecap_train_phenotyping_model(
  data, surrogates, feature_selected)
model

# ## Try a different method
# library(e1071)
# model2 <- phecap_train_phenotyping_model(
#   data, surrogates, feature_selected, 
#   method = "svm")
# model2

## Validate phenotyping model using validation label
validation <- phecap_validate_phenotyping_model(
  data, model)
validation

## Validate phenotyping model using validation label
round(validation$valid_roc[
  validation$valid_roc[, "FPR"] <= 0.2, ], 3)

# ## Plot ROC curve
# phecap_plot_roc_curves(validation)


## Which cutoff correspond to FPR closest to 0.05
idx <- which.min(abs(validation$valid_roc[, "FPR"] - 0.05))
cut.fpr95 <- validation$valid_roc[idx, "cutoff"]


## Apply the model to all the patients to obtain predicted phenotype prob and case status
phenotype <- phecap_predict_phenotype(data, model)
## Use the cutoff that gives 0.05 FPR (type I error)
case_status <- ifelse(phenotype$prediction >= cut.fpr95, 1, 0)
predict.table <- cbind(phenotype, case_status)
predict.table[1:10, ]


#############################################
### R code for causal inference
#############################################
## Generate confounder U and potential outcome (Y(1), Y(0))
rm(list=ls())
set.seed(1)
### Sample size N
N = 10000
### Simulate an unmeasured confounder
U = rnorm(N)
### Potential outcome E[Y(a)|U]=1+2a+2U, a=0,1
a=1; Y1 = rnorm(n=N,mean=1+2*a+2*U)
a=0; Y0 = rnorm(n=N,mean=1+2*a+2*U)
id = paste0("ID",1:N)

## The potential outcomes look like
data.frame(patient=id, treated=Y1,control=Y0)[1:3,]

#Each patient has a pair of potential outcomes ("fate")
## Generate treatment assignment A: a ticket to see Y(a)
#A depends on U, we see Y(a) if A=a, for a=0,1

### 1=treated, 0=control
A = rbinom(n=N,size=1,p=plogis(U)) 
### The observed outcome
Y = Y1*A + Y0*(1-A)


## What we get to see using ticket A is
Y1.obs=Y1; Y1.obs[A==0]=NA
Y0.obs=Y0; Y0.obs[A==1]=NA
data.frame(patient=id, A,Y,
           treated=Y1.obs,control=Y0.obs)[1:3,]


## Average Treatment Effect ATE = E[Y(1)-Y(0)]
(ATE = mean(Y1-Y0))


## Outcome regression w/o adjusting for U
lm(Y~A)$coef["A"]


## G-computation assuming U is measured
# (1) Fit outcome regression
m.OR = lm(Y~A+U)
# (2) Predict the pair of potential outcomes for each individual
Y1.pred = predict(m.OR,newdata = data.frame(Y,A=1,U))
Y0.pred = predict(m.OR,newdata = data.frame(Y,A=0,U))
# (3) Estimate ATE by definition: E[Y(1)-Y(0)]
mean(Y1.pred-Y0.pred)

## In a linear additive model, this is equivalent to
lm(Y~A+U)$coef["A"]


## Generate proxies of U
### A negative control exposure
Z  = U + rnorm(N)
### A negative control outcome
W  = U + rnorm(N)

## We don't expect treatment A to have effect on W
summary(lm(W~A))$coef
## We don't expect Z to have effect on Y
summary(lm(Y~Z))$coef


## Run two stage least squares
# Stage I: fit E[W|A,Z], predict W.hat
m.W_AZ = lm(W~A+Z)
W.hat = predict(m.W_AZ)

# Stage II: treat W.hat as U, fit E[Y|A,W.hat]
m.Y_AW = lm(Y~A+W.hat)
coef(m.Y_AW)

## Alternatively, use gmm package
# You might need to install the "gmm" package
# install.packages("gmm")
m = gmm::gmm(g=Y~A+W, x=~A+Z)
summary(m)$coef


